</div><!-- Wrapper Div Ends-->
</body>
<script src="https://uidai.gov.in/templates/tjbase/js/jquery-3.3.1.min.js" type="text/javascript"></script>
<script src="https://uidai.gov.in/media/jui/js/jquery-migrate.min.js" type="text/javascript"></script>
<script src="https://uidai.gov.in/templates/tjbase/js/bootstrap-3.3.7.min.js" type="text/javascript" defer="defer" async="async"></script>
<script src="https://uidai.gov.in/templates/tjbase/js/custom.js" type="text/javascript" defer="defer" async="async"></script>
</html>