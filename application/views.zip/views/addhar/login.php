<?php $this->load->view('addhar/header'); ?>

<?php $this->load->view('addhar/footer'); ?>